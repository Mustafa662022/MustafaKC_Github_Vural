﻿using System;

namespace MustafaKC_Vural
{
    class Program
    {
        static void Main(string[] args)
        {
            string Benutzer;
            int Frage1, Frage2;

            Console.WriteLine("Geben Sie Ihren Namen ein");
            Benutzer = Console.ReadLine();

            Console.WriteLine("Was ist eine Methode?");
            string A1 = + "Einen Lösungsweg";
            string A2 = + "In Phyton gibst sowas nicht";
            string A3 = + "Das Code, welches iin der Klammer ist";
            string A4 = + "" ;
            Console.ReadLine();


            Frage1 = Convert.ToInt32();
            if (Frage1 == true)
            {
                Console.WriteLine("richtig beantwortet");
            }
            else
            {
                Console.WriteLine("Die Antwort ist falsch");
            }
            Console.ReadLine();

            Console.WriteLine("Was ist ein Objekt?");
            string S1 = + "Einen Lösungsweg";
            string S2 = + "In Phyton gibst sowas nicht";
            string S3 = + "";
            string S4 = + "";
            Console.ReadLine();

            if (Frage2 == true)
            {
                Console.WriteLine("richtig beantwortet");
            }
            else
            {
                Console.WriteLine("Die Antwort ist falsch");
            }
            Console.ReadLine();
        }
    }
}
