﻿using System;

namespace MustafaKC_Vural
{
    class Program
    {
        static void Main(string[] args)
        {
            string Benutzer;
            int Frage1, Frage2;

            Console.WriteLine("Geben Sie Ihren Namen ein");
            Benutzer = Console.ReadLine();

            Console.WriteLine("Was ist eine Methode?");
            string A1 = + "Einen Lösungsweg";
            string A2 = + "In Phyton gibst sowas nicht";
            string A3 = + "Das Code, welches in der Klammer ist";
            string A4 = + "Das sind die Befehle, z.b. open door" ;
            Console.ReadLine();


            Frage1 = Convert.ToInt32();
            if (Frage1 == true)
            {
                Console.WriteLine("richtig beantwortet");
            }
            else
            {
                Console.WriteLine("Die Antwort ist falsch");
            }
            Console.ReadLine();

            Console.WriteLine("Was ist ein Objekt?");
            string S1 = + "Ist ein Objekt";
            string S2 = + "In Phyton gibst sowas nicht";
            string S3 = + "Das ist das Befehle, z.b. move right";
            string S4 = + "Führt Befehles aus";
            Console.ReadLine();

            Frage2 = Convert.ToInt32();
            if (Frage2 == true)
            {
                Console.WriteLine("richtig beantwortet");
            }
            else
            {
                Console.WriteLine("Die Antwort ist falsch");
            }
            Console.ReadLine();
        }
    }
}
